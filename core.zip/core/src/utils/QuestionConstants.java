package utils;

public interface QuestionConstants {

    public static int qns1 = 1;
    public static String qns1Text = "Is eating vegetables good for your health?";
    public static boolean qns1Ans = true;

    public static int qns2 = 2;
    public static String qns2Text = "Should you consume more sweet beverages than eating vegetables?";
    public static boolean qns2Ans = false;

    public static int qns3 = 3;
    public static String qns3Text = "Is it important to maintain a healthy diet with a well balanced meal?";
    public static boolean qns3Ans = true;

    public static int totalQns = 3;
}
