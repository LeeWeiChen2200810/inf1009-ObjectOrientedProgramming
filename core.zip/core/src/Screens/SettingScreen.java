package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.mygdx.game.MyGdxGame;

import managers.InputManager;

import managers.GameScreenManager;
import utils.ScrollingBackground;
import utils.Settings;


public class SettingScreen extends BaseScreen{
    private Stage stage;
    // Settings class
    private Skin skin;
    private Settings settings;
    private InputManager inputManager;
    private Slider musicVolumeSlider;
    private ScrollingBackground background;

    public SettingScreen(final MyGdxGame app) {

        super(app);
        background = new ScrollingBackground();
        stage = new Stage(new ScreenViewport());
        // Load skin file
        skin = app.getGenericAssetsManager().manager.get("skins/clean-crispy-ui.json", Skin.class);

        // Create UI elements
        Label title = new Label("Settings", new Label.LabelStyle(new BitmapFont(), Color.WHITE));


        TextButton backButton = new TextButton("Save Setting", skin);
        backButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                // go back to main menu
                app.getGameScreenManager().setScreen(GameScreenManager.STATE.MAIN_MENU);
            }
        });

        musicVolumeSlider = new Slider(0, 1, 0.1f, false, skin); // min, max, step size, is vertical, skin
        musicVolumeSlider.setValue(Settings.getMusicVolume()); // set the initial value to the current setting
        musicVolumeSlider.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                Settings.changeMusicVolume(musicVolumeSlider.getValue()); // update the setting when the slider is changed
            }
        });

        Label musicVolumeLabel = new Label("Music Volume:", new Label.LabelStyle(new BitmapFont(), Color.WHITE));

        // Add UI elements to the stage
        stage.addActor(title);
        stage.addActor(musicVolumeLabel);
        stage.addActor(musicVolumeSlider);
        stage.addActor(backButton);

        // Position UI elements
        float centerX = Gdx.graphics.getWidth() / 2f;
        float centerY = Gdx.graphics.getHeight() / 2f;
        // Position UI elements
        float elementWidth = Gdx.graphics.getWidth() * 0.6f;
        float elementHeight = 50f;
        float spacing = 20f;
        float y = centerY + 300f;

        title.setPosition(centerX - title.getWidth() / 2f, y);


        y -= elementHeight + spacing;
        musicVolumeLabel.setPosition(centerX - elementWidth / 2f, y);
        musicVolumeSlider.setSize(elementWidth, elementHeight);
        musicVolumeSlider.setPosition(centerX - elementWidth / 2f, y - musicVolumeSlider.getHeight());


        y -= elementHeight + spacing;
        backButton.setSize(elementWidth, elementHeight);
        backButton.setPosition(centerX - backButton.getWidth() / 2f, y - backButton.getHeight());


    }
    @Override
    public void update(float delta) {

    }


    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.2f, 0.2f, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        app.getBatch().begin();
        background.updateAndRender(delta, app.getBatch());
        app.getBatch().end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}