package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.MoveToAction;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.mygdx.game.MyGdxGame;
import managers.GameScreenManager;

public class HelpScreen extends BaseScreen {
    private MyGdxGame app;
    private Stage stage;
    private Texture image;
    private Skin skin;
    private BitmapFont font;
    private float imageScale;
    private SpriteBatch batch;
    private Texture helpTexture;


    public HelpScreen(final MyGdxGame app) {
        super(app);
        batch = new SpriteBatch();
        // Load assets
        app.getGenericAssetsManager().load_help();
        app.getGenericAssetsManager().manager.finishLoading();
        skin = app.getGenericAssetsManager().manager.get("skins/clean-crispy-ui.json", Skin.class);
        // Images to use for display
        helpTexture = app.getGenericAssetsManager().manager.get("images/help-1.png", Texture.class);
        imageScale = MyGdxGame.APP_DESKTOP_WIDTH / helpTexture.getWidth();

        // Create a new stage to hold the UI elements
        stage = new Stage(new ScreenViewport());


        // Create and position button
        TextButton button = new TextButton("Back", skin);
        button.setPosition(MyGdxGame.APP_DESKTOP_WIDTH - button.getWidth(), MyGdxGame.APP_DESKTOP_HEIGHT - button.getHeight());

        // Add listener to button to change screen when clicked
        button.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                app.getGameScreenManager().setScreen(GameScreenManager.STATE.MAIN_MENU);
            }
        });

        // Add button to stage
        stage.addActor(button);

    }

    @Override
    public void update(float delta) {

    }

    @Override
    public void render(float delta) {
        Gdx.input.setInputProcessor(stage);
        // Clear screen with black color
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Set batch projection matrix to screen dimensions
        batch.setProjectionMatrix(stage.getCamera().combined);


        // Draw help image
        batch.begin();
        batch.draw(helpTexture, 0, 0, MyGdxGame.APP_DESKTOP_WIDTH, MyGdxGame.APP_DESKTOP_HEIGHT);
        batch.end();

        // Handle input events and update/draw stage
        stage.act(delta);
        stage.draw();
    }
    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}

