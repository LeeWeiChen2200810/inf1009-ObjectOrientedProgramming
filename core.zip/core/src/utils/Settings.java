package utils;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;

public class Settings {
    private static String moveLeftKey;
    private static String moveRightKey;
    private static String jumpKey;
    private static String downKey;
    private static float musicVolume;
    private static int highestScore;
    private static String shootKey;
    private static int currentScore;

    private static Preferences prefs = Gdx.app.getPreferences("Warrior Preferences");

    static {
        highestScore = prefs.getInteger("highestScore", 0);
        musicVolume = prefs.getFloat("musicVolume", 0.5f);
        currentScore = prefs.getInteger("currentScore", 0);
    }

    private Settings() {}

    public static float getMusicVolume() {
        return prefs.getFloat("musicVolume");
    }

    public static void changeMusicVolume(float newMusicVolume) {
        musicVolume = newMusicVolume;
        prefs.putFloat("musicVolume", newMusicVolume);
        prefs.flush();
    }



    public static int getHighestScore() {
        return prefs.getInteger("highestScore");
    }

    public static void setHighestScore(int newHighestScore) {
        // only when the current score higher than the Pref's higherscore it will replace it
        highestScore = prefs.getInteger("highestScore");
        if(highestScore < newHighestScore) {
            prefs.putInteger("highestScore", newHighestScore);
            prefs.flush();
            highestScore = newHighestScore;
        }
    }

    public static void setCurrentScore(int newCurrentScore) {
        currentScore = newCurrentScore;
        prefs.putString("currentScore", String.valueOf(currentScore));
        prefs.flush();
    }

    public static int getCurrentScore() {
        return prefs.getInteger("currentScore");
    }
}
